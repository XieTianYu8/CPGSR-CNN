import os
import random
import numpy as np
import xlwt
import re
import pandas as pd
from openpyxl import Workbook
import shutil
from decimal import Decimal
from pandas import DataFrame
# import pywt


def read_data(path, newpath, xlsx_data, txt_num):
    '''
    * read_Data.py file is placed under the same root directory as the read data folder.
    * path：Enter the read data folder path.
    * Read the data folder layout as shown in the example.
    * After rerunning to read the data, if you rerun to read, you need to delete the newly generated **_ok folder in the Data folder before starting the operation.
    '''
    os.mkdir(newpath)
    os.mkdir(xlsx_data)
    path = path
    file_name_lists = []
    for file_name in os.listdir(path):
        file_name_lists.append(file_name)
    for file_name_list in file_name_lists:
        root_ = []
        dirs_ = []
        a = 0
        for root, dirs, files in os.walk(path + '\\' + file_name_list):
            root_.append(root)
            dirs_.append(dirs)
            dirs__ = dirs_[0]
        file_name_after = newpath + '\\' + file_name_list + '_ok'
        if not os.path.exists(file_name_after):
            os.mkdir(file_name_after)
        for i in root_[1:]:
            file_name_after_ = file_name_after + '\\' + dirs__[a]
            if not os.path.exists(file_name_after_):
                os.mkdir(file_name_after_)
            txt_ = []
            for file_name_ in os.listdir(i):
                txt_.append(i + '\\' + file_name_)
            txt_num = txt_num  # 取多少文件
            txt_ = txt_[-txt_num:]
            num_all = []
            for txt_name in txt_:
                contents = []
                with open(txt_name, 'r') as f:
                    for line in f.readlines():
                        line = line.split('\n')
                        line = line[0].split('\t')
                        line = list(map(float, line))
                        contents.append(line)
                for content in contents:
                    num_all.append("%.10f" % (float(content[1]) / txt_num))
                if len(num_all) > len(contents):
                    for ii in range(len(num_all)):
                        if ii < len(contents):
                            num_all[ii] = "%.10f" % (num_all[ii] + float(num_all[ii + len(contents)]))
                        else:
                            num_all.pop()
                num_all = list(map(float, num_all))
                f.close()
                txt_name_after = newpath + '\\' + file_name_list + '_ok\\' + dirs__[a] + "\\" + dirs__[a] + ".txt"
                with open(txt_name_after, "w") as ff:
                    for li in num_all:
                        ff.write(str(li) + "\n")
                ff.close()
            a += 1
        print(file_name_list, "Data reading completed！")
    print("All data read completed！")


def remove_bd(newpath):
    path = newpath
    nn_ = []
    file_name_lists = []
    for file_name in os.listdir(path):
        file_name_lists.append(file_name)
    for file_name_list in file_name_lists:
        n_p = path + '\\' + file_name_list + '_z'
        nn_.append(n_p)
        os.mkdir(n_p)
        root_ = []
        dirs_ = []

        for root, dirs, files in os.walk(path + '\\' + file_name_list):
            root_.append(root)
            dirs_.append(dirs)
            dirs__ = dirs_[0]
        root_.pop(0)
        root__ = root_[-1]
        dirs___ = dirs__[-1]
        root_.pop()
        dirs__.pop()
        bd_name = root__ + '\\' + dirs___ + '.txt'
        for i in range(len(root_)):
            data = []
            file_name = root_[i] + '\\' + dirs__[i] + '.txt'
            file_name_ = n_p + '\\' + dirs__[i] + '.txt'
            with open(bd_name) as bd_f:
                bd_file = bd_f.read().split('\n')
            bd_f.close()
            with open(file_name, 'r+') as f:
                file = f.read().split('\n')
            f.close()
            del (bd_file[-1])
            del (file[-1])
            bd_file = list(map(float, bd_file))
            file = list(map(float, file))
            for i in range(len(bd_file)):
                i_num = "%.10f" % ((file[i]) / (bd_file[i]))
                data.append(i_num)
            with open(file_name_, 'w') as f_:
                f_.truncate(0)
                for ii in data:
                    f_.write(ii + "\n")
            f_.close()
    print('Successfully removed the backing!')
    return nn_


def writeinexcel(path, nn):
    path = path
    le_ = 0
    wb1 = Workbook()
    w1 = wb1.active
    w1.title = "one"

    ipath_ = path[0]
    file_name_lists_ = []
    file_name_lists = []

    for file_name_ in os.listdir(ipath_):
        num_str = re.sub('\D', '', file_name_)
        if num_str:
            file_name_lists_.append(num_str)
    file_name_lists_ = list(map(int, file_name_lists_))
    file_name_lists_.sort()
    le = len(file_name_lists_)

    # openpyxl行列从1开始
    for le_i in range(le):
        w1.cell(row=1, column=le_i + 1 + le_, value=file_name_lists_[le_i])

    for file_name_ in os.listdir(ipath_):
        file_name_lists.append(file_name_)

    def safe_sort_key(x):
        s = x[:-nn]
        # 为空 或者不是纯数字 → 返回兜底0，避免int转换报错
        if not s or not s.isdigit():
            return 0
        return int(s)

    file_name_lists.sort(key=safe_sort_key)

    for i_a in range(len(file_name_lists)):
        file_fullpath = os.path.join(ipath_, file_name_lists[i_a])
        ii = 2
        with open(file_fullpath, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                w1.cell(row=ii, column=i_a+1, value=float(line))
                ii += 1

    p1 = path[0] + ".xlsx"
    wb1.save(p1)
    return p1





def del_files(path, name1):
    if os.path.exists(path):
        shutil.rmtree(path, ignore_errors=False, onerror=None)
    if os.path.exists(name1):
        shutil.rmtree(name1, ignore_errors=False, onerror=None)
    print("Data environment cleanup succeeded!")


def koumanbian(x, data_all, a, b, e, f, i, j, m, n):
    aa = []
    j_ = 0

    line1 = list(range(a - 1, b))
    # print("line1:",len(line1))
    line2 = list(range(e - 1, f))
    # print("line2:", len(line2))
    line3 = list(range(i - 1, j))
    # print("line3:", len(line3))
    line4 = list(range(m - 1, n))
    # print("line4:", len(line4))
    line_z = list(range(a - 1, n))
    # print(len(line_z))

    listall = line1 + line2 + line3 + line4
    # print(len(listall))

    for i in x:
        zz1 = np.polyfit(listall, i, 5)  # 拟合
        pp1 = np.poly1d(zz1)
        jj = data_all[j_]

        # aa.append(i/pp1([i for i in range(len(i))]))
        aa.append(np.log(jj / pp1(line_z)))
        # aa.append(jj / pp1(line_z))
        j_ += 1

    return np.array(aa)


def dif(path):
    # Weak characteristic absorption region 1
    a = 640
    b = 697

    # Characteristic absorption peak 1
    c = 698
    d = 735

    # Weak characteristic absorption region 2
    e = 736
    f = 885

    # Characteristic absorption peak 2
    g = 886
    h = 926

    # Weak characteristic absorption region 3
    i = 927
    j = 1100

    # Characteristic absorption peak 3
    k = 1101
    l = 1144

    # Weak characteristic absorption region 4
    m = 1145
    n = 1190

    data = pd.read_excel(path)
    columns = data.columns
    wb_all = Workbook()
    wb_all.create_sheet(index=0, title="all")
    ws_all = wb_all.active

    data_line_1 = data.iloc[a - 1:b, :]
    data_peak_1 = data.iloc[c - 1:d, :]
    data_line_2 = data.iloc[e - 1:f, :]
    data_peak_2 = data.iloc[g - 1:h, :]
    data_line_3 = data.iloc[i - 1:j, :]
    data_peak_3 = data.iloc[k - 1:l, :]
    data_line_4 = data.iloc[m - 1:n, :]

    data_line_1 = np.array(data_line_1)
    data_peak_1 = np.array(data_peak_1)
    data_line_2 = np.array(data_line_2)
    data_peak_2 = np.array(data_peak_2)
    data_line_3 = np.array(data_line_3)
    data_peak_3 = np.array(data_peak_3)
    data_line_4 = np.array(data_line_4)

    line_1_shape = data_line_1.shape[0]
    line_2_shape = data_line_2.shape[0]
    line_3_shape = data_line_3.shape[0]
    line_4_shape = data_line_4.shape[0]
    peak_1_shape = data_peak_1.shape[0]
    peak_2_shape = data_peak_2.shape[0]
    peak_3_shape = data_peak_3.shape[0]

    data_all = np.concatenate(
        (data_line_1, data_peak_1, data_line_2, data_peak_2, data_line_3, data_peak_3, data_line_4), axis=0)
    # print(data_all.shape)
    data_all = pd.DataFrame(data_all, columns=columns)
    data_all = data_all.T
    data_all = np.array(data_all)
    # print(data_all.shape)
    data_line_all = np.concatenate((data_line_1, data_line_2, data_line_3, data_line_4), axis=0)
    data_line_all = pd.DataFrame(data_line_all, columns=columns)
    data_line_all = data_line_all.T
    data_line_all = np.array(data_line_all)
    # print(data_line_all.shape)
    # print(data_all.shape)
    data_deal_all_line = koumanbian(data_line_all, data_all, a, b, e, f, i, j, m, n)
    deal_data_line_all = pd.DataFrame(data_deal_all_line)
    # print("deal_data_line_all",deal_data_line_all)
    columns_ = deal_data_line_all.columns
    # all_data
    l = len(columns_)
    i1 = 0
    for i in range(l):
        i1 += 1
        lie = deal_data_line_all[columns_[i]]
        for j in range(len(lie)):
            ws_all.cell(1, i + 1, i1)
            ws_all.cell(j + 2, i + 1, lie[j])
    for col_i in range(len(columns)):
        col = columns[col_i]
        ws_all.cell(col_i + 2, l + 1, col)
    ws_all.cell(1, l + 1, l + 1)
    name = path + '.xlsx'
    wb_all.save(name)
    print("Data differential completion!")
    return name, line_1_shape, line_2_shape, line_3_shape, line_4_shape, peak_1_shape, peak_2_shape, peak_3_shape


#def Extended_data(path, end_file_name0):
    wb = Workbook()
    wb.create_sheet(index=0, title="all")
    ws = wb.active

    data1 = pd.read_excel(path)
    columns1 = data1.columns
    le = 0
    for i in range(data1.shape[1]):
        lie1 = data1[columns1[i]]
        data_1 = lie1
        ws.cell(1, i + 1, str(columns1[i]))
        for ii in range(len(data_1)):
            ws.cell(ii + 2, i + 1, data_1[ii])
    le += int(data1.shape[0])
    index1 = data1.index
    for time in range(40):
        a = random.uniform(0, 1.25)
        a = round(a, 3)
        b = random.uniform(0, 1.25)
        b = round(b, 3)
        if a == 0 or b == 0:
            a += 0.1
            b += 0.1
        for i in range(data1.shape[0]):
            for j in range(data1.shape[0]):
                ind1 = list(data1.loc[index1[i]])
                # ind1.pop(0)
                ind2 = list(data1.loc[index1[j]])
                # ind2.pop(0)
                ind1 = np.array(ind1)
                ind2 = np.array(ind2)
                '''Combination Rules'''
                a = float(a)
                b = float(b)
                data_1 = a * ind1 + b * ind2
                for iii in range(len(data_1)):
                    ws.cell(le + 2 + j, iii + 1, data_1[iii])
            le += int(data1.shape[0])
        print("circulate", time, "time")
    wb.save(end_file_name0)
    path = to_pkl(end_file_name0)
    return path


def to_pkl(path):
    # Read excel files
    df1 = DataFrame(pd.read_excel(path))
    dir_name = os.path.dirname(path)
    base_name = os.path.basename(path)
    suffix = base_name.split(".")[0]
    path_ = dir_name + "/" + suffix + ".pkl"
    df1.to_pickle(path_)
    return path_


def run():
    oldpath = "File address"  # Original Data Location
    newpath = oldpath + "_deal_dwt"  # Generate Process Data Location
    xlsx_data = oldpath + "_xlsx_dwt"




    txt_num = 40 # Average the last number of txt files
    nn = 4
    del_files(newpath, xlsx_data)
    read_data(oldpath, newpath, xlsx_data, txt_num)
    path1 = remove_bd(newpath)
    path2 = writeinexcel(path1, nn)

    path3, line_1_shape, line_2_shape, line_3_shape, line_4_shape, peak_1_shape, peak_2_shape, peak_3_shape = dif(path2)
    # path4 = Extended_data(path3, end_file_name0) # This function is used to expand the data.
    # path5 = Dwt_data(path3, end_file_name1)
    # Distribute_data(path5, end_file_name2, end_file_name3, end_file_name3_1, end_file_name3_2,
    #                 end_file_name3_3, 74, 151, 180, 51, 37, 38, 39)
    return path3


if __name__ == "__main__":
    out = run()
    print("输出文件：", out)