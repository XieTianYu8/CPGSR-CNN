# =========================
# 1. 基础库
# =========================
import os
import shutil
import numpy as np
import random
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from keras.models import Model
from keras.layers import Dense, Flatten, Conv1D, MaxPooling1D, Input
from keras.utils import plot_model
from sklearn.metrics import r2_score
from openpyxl import Workbook
SEED = 233
os.environ["PYTHONHASHSEED"] = str(SEED)
# 如果你用GPU且想尽量确定性（TF 2.10+通常有效）
os.environ["TF_DETERMINISTIC_OPS"] = "1"
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)
# =========================
# 2. 全局参数（只需要改这里）
# =========================
NUM_SCALE = 100              # 浓度缩放因子（标签会除以它，输出再乘回去）
FEATURE_LEN = 145             # 每条光谱的特征长度（你的特征列数）
BATCH_SIZE = 32
EPOCHS = 100
OPTIMIZER = tf.keras.optimizers.Adam(learning_rate=1e-4)
LOSS = "mean_squared_error"
# =========================
# 3. 自定义指标：R²
# =========================
def coeff_determination(y_true, y_pred):
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)
    ss_res = tf.reduce_sum(tf.square(y_true - y_pred))
    ss_tot = tf.reduce_sum(tf.square(y_true - tf.reduce_mean(y_true)))
    return 1.0 - ss_res / (ss_tot + tf.keras.backend.epsilon())
# =========================
# 4. 表格 -> PKL（新增功能：没有pkl就自动生成）
# =========================
def table_to_pkl(table_path, out_pkl_path, drop_first_row=True):
    """
    把表格文件（xlsx/xls/csv）转成 pkl，供本脚本训练/测试使用。
    默认约定（与你前面说的格式一致）：
    - 每一行是一条样本
    - 前 FEATURE_LEN 列是特征（默认 145 列）
    - 最后一列是标签（浓度）
    - 如果你的表格第 1 行是“索引/波长标题行”，则 drop_first_row=True 会把它删掉
    如果你的列数不止 FEATURE_LEN+1：
    - 会取“前 FEATURE_LEN 列作为特征”
    - 取“最后一列作为标签”
    """
    if not os.path.exists(table_path):
        raise FileNotFoundError(f"找不到表格文件：{table_path}")
    ext = os.path.splitext(table_path)[1].lower()
    if ext in [".xlsx", ".xls"]:
        df = pd.read_excel(table_path, sheet_name=0)
    elif ext == ".csv":
        df = pd.read_csv(table_path)
    else:
        raise ValueError(f"不支持的文件类型：{ext}（请用 xlsx/xls/csv）")
    # 如果第一行是索引/波长标题行，不是样本 -> 删除它
    if drop_first_row:
        df = df.iloc[1:, :].reset_index(drop=True)
    # 全部转数值，无法转的变 NaN
    df = df.apply(pd.to_numeric, errors="coerce")
    # 删除含 NaN 的行（避免训练时出现异常/误差爆炸）
    before = len(df)
    df = df.dropna(axis=0).reset_index(drop=True)
    after = len(df)
    # 列数检查：至少 FEATURE_LEN 个特征 + 1 个标签
    if df.shape[1] < FEATURE_LEN + 1:
        raise ValueError(
            f"列数不够：当前 {df.shape[1]} 列，但至少需要 {FEATURE_LEN+1} 列（{FEATURE_LEN}特征 + 1标签）"
        )
    # 如果列数多于 FEATURE_LEN+1：只取前 FEATURE_LEN 列当特征 + 最后一列当标签
    if df.shape[1] != FEATURE_LEN + 1:
        df = pd.concat([df.iloc[:, :FEATURE_LEN], df.iloc[:, -1]], axis=1)
    # 保存为 pkl
    os.makedirs(os.path.dirname(out_pkl_path), exist_ok=True)
    df.to_pickle(out_pkl_path)
    print(f"✅ 表格已转为 pkl：{out_pkl_path}（有效行 {after}/{before}）")
# =========================
# 5. 数据加载（pkl）
# =========================
def load_pkl_data(pkl_path, num=NUM_SCALE):
    """
    pkl 结构：
    前 FEATURE_LEN 列：特征
    最后一列：标签
    """
    if not os.path.exists(pkl_path):
        raise FileNotFoundError(f"找不到 pkl 文件：{pkl_path}")
    df = pd.read_pickle(pkl_path)
    X = np.expand_dims(df.values[:, :-1].astype(float), axis=2)  # (N, 145) -> (N, 145, 1)
    y = df.values[:, -1].astype(float) / num                     # 标签缩放
    return X, y
# =========================
# 6. CNN 模型结构（训练 & 测试共用）
# =========================
def build_cnn_model(model_png=None):
    """
    FEATURE_LEN × 1 → CNN → 1
    """
    inputs = Input(shape=(FEATURE_LEN, 1))
    x = Conv1D(16, 3, padding="same", activation="relu")(inputs)
    x = Conv1D(16, 3, padding="same", activation="relu")(x)
    x = MaxPooling1D(2)(x)
    x = Conv1D(32, 3, padding="same", activation="relu")(x)
    x = MaxPooling1D(2)(x)
    x = Flatten()(x)
    outputs = Dense(1, activation="linear")(x)
    model = Model(inputs, outputs)
    model.summary()
    if model_png is not None:
        plot_model(model, to_file=model_png, show_shapes=True)
    return model
# =========================
# 7. 训练流程：直接使用手动划分好的训练集、验证集pkl
# =========================
def train_model(train_pkl_path, val_pkl_path, result_dir="Result_no_cnn"):
    # 清理并创建目录
    if os.path.exists(result_dir):
        shutil.rmtree(result_dir)
    os.mkdir(result_dir)
    # 输出路径
    model_png = f"{result_dir}/CNN.png"
    model_json = f"{result_dir}/model.json"
    model_weights = f"{result_dir}/model.weights.h5"
    loss_excel = f"{result_dir}/loss.xlsx"
    result_excel = f"{result_dir}/predict.xlsx"
    mae_r2_excel = f"{result_dir}/mae_r2.xlsx"
    loss_png = f"{result_dir}/loss.png"
    r2_png = f"{result_dir}/r2.png"

    # 直接加载你已经分好的训练集、验证集，不再内部切分
    X_train, y_train = load_pkl_data(train_pkl_path)
    X_val, y_val = load_pkl_data(val_pkl_path)
    print(f"训练集样本数: {len(X_train)} , 验证集样本数: {len(X_val)}")

    # 模型
    model = build_cnn_model(model_png)
    model.compile(
        optimizer=OPTIMIZER,
        loss=LOSS,
        metrics=[coeff_determination]
    )
    history = model.fit(
        X_train, y_train,
        batch_size=BATCH_SIZE,
        epochs=EPOCHS,
        validation_data=(X_val, y_val)
    )
    # 验证集预测（用于保存预测结果 + 计算指标）
    y_pred = model.predict(X_val)
    # 保存模型
    with open(model_json, "w", encoding="utf-8") as f:
        f.write(model.to_json())
    model.save_weights(model_weights)
    # 保存预测结果
    save_predict_excel(y_pred, y_val, result_excel)
    # MAE / R²
    mae = calc_mae(y_pred, y_val)
    mape = calc_mape(y_pred, y_val)
    r2 = r2_score(y_val, y_pred)
    save_mae_r2(mae,mape, r2, mae_r2_excel)
    # loss & R² 曲线
    save_history(history, loss_excel, loss_png, r2_png)
    print("✅ 训练完成")
    return model_weights
# =========================
# 8. 测试流程（只加载权重，外部测试集逻辑不变）
# =========================
def run_test_model(pkl_path, model_weights, result_excel="test_result.xlsx"):
    X, y = load_pkl_data(pkl_path)
    model = build_cnn_model()
    model.load_weights(model_weights)
    model.compile(
        optimizer=OPTIMIZER,
        loss=LOSS,
        metrics=[coeff_determination]
    )
    y_pred = model.predict(X)
    save_predict_excel(y_pred, y, result_excel)
    calc_mae(y_pred, y)
    calc_mape(y_pred, y)
    print("R2:", r2_score(y, y_pred))
    print("✅ 测试完成")
# =========================
# 9. 工具函数
# =========================
def calc_mae(y_pred, y_true):
    y_pred = np.reshape(y_pred, len(y_pred)) * NUM_SCALE
    y_true = np.array(y_true) * NUM_SCALE
    mae = np.mean(np.abs(y_pred - y_true))
    print(f"MAE: {mae:.2f} ppb")
    return mae
def calc_mape(y_pred, y_true, eps=1e-6):
    """
    MAPE = mean(|y_pred - y_true| / |y_true|) * 100%
    eps：防止真实值为 0 时除零
    """
    y_pred = np.reshape(y_pred, len(y_pred)) * NUM_SCALE
    y_true = np.array(y_true) * NUM_SCALE
    mape = np.mean(
        np.abs(y_pred - y_true) / (np.abs(y_true) + eps)
    ) * 100
    print(f"MAPE: {mape:.2f} %")
    return mape
def save_predict_excel(predicted, y_true, path):
    wb = Workbook()
    ws = wb.active
    ws.append(["Predicted", "Real"])
    for i in range(len(predicted)):
        ws.append([
            float(predicted[i][0]) * NUM_SCALE,
            float(y_true[i]) * NUM_SCALE
        ])
    wb.save(path)
def save_mae_r2(mae, mape, r2, path):
    wb = Workbook()
    ws = wb.active
    ws.append(["MAE", "MAPE (%)",  "R2"])
    ws.append([mae, mape, r2])
    wb.save(path)
def save_history(history, excel_path, loss_png, r2_png):
    hist = pd.DataFrame(history.history)
    hist.to_excel(excel_path, index=False)
    # loss
    plt.figure()
    plt.plot(hist["loss"], label="train")
    plt.plot(hist["val_loss"], label="val")
    plt.legend()
    plt.savefig(loss_png, dpi=300)
    # R²
    plt.figure()
    plt.plot(hist["coeff_determination"], label="train")
    plt.plot(hist["val_coeff_determination"], label="val")
    plt.legend()
    plt.savefig(r2_png, dpi=300)
# =========================
# 10. 主入口（表格->pkl，训练+外部测试）
# =========================
if __name__ == "__main__":
    # =========================
    # 你只需要改这里：填好训练集、验证集、外部测试集表格路径
    # =========================
    # 训练数据
    train_table = r"D:/NOProject/data/CNN返修/CNN/train.xlsx"
    train_pkl = r"D:/NOProject/data/CNN返修/CNN/train.pkl"

    # 【新增】你手动划分好的验证集
    val_table = r"D:/NOProject/data/CNN返修/CNN/valid.xlsx"
    val_pkl = r"D:/NOProject/data/CNN返修/CNN/valid.pkl"

    # 外部测试数据（完全保留原来逻辑）
    test_table = r"D:\NOProject\data\CNN返修\CNN/test2.xlsx"
    test_pkl = r"D:\NOProject\data\CNN返修\CNN/test2.pkl"

    # train_table = r"D:/NOProject/data/yuan/CNN/train.xlsx"
    # train_pkl = r"D:/NOProject/data/yuan/CNN/train.pkl"
    #
    # # 【新增】你手动划分好的验证集
    # val_table = r"D:/NOProject/data/yuan/CNN/valid.xlsx"
    # val_pkl = r"D:/NOProject/data/yuan/CNN/valid.pkl"
    #
    # # 外部测试数据（完全保留原来逻辑）
    # test_table = r"D:\NOProject\data\yuan\CNN/test.xlsx"
    # test_pkl = r"D:\NOProject\data\yuan\CNN/test.pkl"



    # 是否删除表格第一行（标题行）
    DROP_FIRST_ROW_TRAIN = True   # 训练集表格第一行是表头
    DROP_FIRST_ROW_VAL = False    # 验证集表格第一行就是样本，按需修改True/False
    DROP_FIRST_ROW_TEST = False   # 外部测试集

    # 转训练集pkl
    if not os.path.exists(train_pkl):
        table_to_pkl(train_table, train_pkl, drop_first_row=DROP_FIRST_ROW_TRAIN)

    # 转验证集pkl
    if not os.path.exists(val_pkl):
        table_to_pkl(val_table, val_pkl, drop_first_row=DROP_FIRST_ROW_VAL)

    # 训练，传入训练pkl、验证pkl
    weights = train_model(train_pkl, val_pkl)

    # 转外部测试集pkl
    if not os.path.exists(test_pkl):
        table_to_pkl(test_table, test_pkl, drop_first_row=DROP_FIRST_ROW_TEST)

    # 外部测试
    run_test_model(test_pkl, weights)
