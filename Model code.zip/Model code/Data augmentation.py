import random
import numpy as np
import pandas as pd
from openpyxl import Workbook

def Extended_data(path, end_file_name0):
    wb = Workbook()
    ws = wb.active
    ws.title = "all"

    # 读取原始数据
    data1 = pd.read_excel(path)

    # 假设最后一列是标签列
    cols = list(data1.columns)
    feature_cols = cols[:-1]
    label_col = cols[-1]

    X = data1[feature_cols].to_numpy(dtype=float)   # 特征数据
    y = data1[label_col].to_numpy()               # 标签数据
    n, p = X.shape

    # 写表头：特征列 + 标签列
    for j, c in enumerate(feature_cols, start=1):
        ws.cell(1, j, str(c))
    ws.cell(1, p + 1, str(label_col))

    # 写入原始数据
    out_row = 2
    for i in range(n):
        for j in range(p):
            ws.cell(out_row, j + 1, float(X[i, j]))
        ws.cell(out_row, p + 1, y[i])
        out_row += 1

    # 扩增数据：生成 40 轮数据，每轮生成 n*n 条新数据（注意会非常大）
    for time in range(80):
        a = round(random.uniform(0.1, 1.25), 3)
        b = round(random.uniform(0.1, 1.25), 3)

        for i in range(n):
            for j in range(n):
                # 生成新的特征数据
                new_x = a * X[i] + b * X[j]

                # 生成新的标签数据：如果是数值型标签，进行线性组合；如果不是数值型标签，生成组合标签字符串
                try:
                    c1 = float(y[i])
                    c2 = float(y[j])
                    new_y = a * c1 + b * c2
                except Exception:
                    new_y = f"{a}*{y[i]}+{b}*{y[j]}"

                # 写入新生成的数据
                for k in range(p):
                    ws.cell(out_row, k + 1, float(new_x[k]))
                ws.cell(out_row, p + 1, new_y)
                out_row += 1

        print(f"第 {time+1} 轮数据扩充完成")

    wb.save(end_file_name0)
    return end_file_name0



# 差分后的最终扩充
path = "File address"
end_file_name0 = "File address"

Extended_data(path, end_file_name0)
