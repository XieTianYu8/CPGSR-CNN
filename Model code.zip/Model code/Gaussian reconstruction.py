import os
# noinspection PyUnresolvedReferences
import random
import numpy as np
# noinspection PyUnresolvedReferences
import pandas as pd
from openpyxl import Workbook,load_workbook
from pandas import DataFrame
import matplotlib.pyplot as plt
# noinspection PyUnresolvedReferences
from pylab import mpl
# noinspection PyUnresolvedReferences
from scipy import stats
# noinspection PyUnresolvedReferences
import math
from scipy.optimize import curve_fit




GAUSSIAN_FILE_INITED = False

def to_gaussian(data1, data2, path, a, D, conc=None):
    """
    data1: x 列表
    data2: y 列表（拟合后的高斯 y 或你要保存的 y）
    path: 生成文件名
    a, D: 本组拟合参数，用于计算偏置 bias = a*D
    conc: 浓度标签（数值/字符串都行），会写到每组数据的最后一列

    行为：本次运行首次调用会清空旧文件；之后追加写入
    写入时：y 会先做 y - a*D 再保存
    """
    global GAUSSIAN_FILE_INITED

    path0 = path.split('.')[0]
    name = path0 + '-Gaussian-data.xlsx'
    bias = a * D  # 你要减掉的偏置项
    # bias = 0
    # 第一次运行：清空旧数据
    if not GAUSSIAN_FILE_INITED:
        wb = Workbook()
        ws = wb.active
        ws.title = "all"
        wb.save(name)
        GAUSSIAN_FILE_INITED = True

    wb = load_workbook(name)
    ws = wb["all"]

    # 空表从第1行写，否则追加
    start_row = ws.max_row + 1 if ws.cell(1, 1).value is not None else 1

    # 最后一列（浓度列）的位置：len(data1)+1
    conc_col = len(data1) + 1

    # 写 data1（x）
    for col, v in enumerate(data1, start=1):
        ws.cell(start_row, col, v)

    # 写 data2（y - a*D）
    for col, v in enumerate(data2, start=1):
        ws.cell(start_row + 1, col, -(float(v) - float(bias)))

    # 写浓度标签到“最后一列”（两行都写同一个 conc）
    if conc is not None:
        ws.cell(start_row, conc_col, conc)
        ws.cell(start_row + 1, conc_col, conc)

    wb.save(name)

def to_pkl(path):
    # Read excel files
    df1 = DataFrame(pd.read_excel(path))
    dir_name = os.path.dirname(path)
    base_name = os.path.basename(path)
    suffix = base_name.split(".")[0]
    path_ = dir_name + "/" + suffix + ".pkl"
    df1.to_pickle(path_)
    return path_


def index_arrangement(data_x):
    indexed_numbers = list(enumerate(data_x))
    # print("indexed_numbers:",indexed_numbers)
    sorted_numbers = sorted(indexed_numbers, key=lambda x: x[1])
    sorted_values = [x[1] for x in sorted_numbers]  # Sorted values
    sorted_indices = [x[0] for x in sorted_numbers]  # Sorted Indexes
    return sorted_values, sorted_indices


def index_return(sorted_indices, sorted_values_i):
    reverse_index = np.argsort(sorted_indices)[::-1]  # Sorts the list from largest to smallest and returns its index.
    reversed_list = np.take(sorted_values_i, reverse_index)
    reversed_list = reversed_list[::-1]
    return reversed_list


def to_data(data1, data2, path):
    """
    参数:
    data1: 分段重构后的数据列表，每个元素是一个分段的结果
    data2: 对应的浓度数据
    path: 保存路径
    """
    wb = Workbook()
    wb.create_sheet(index=0, title="all")
    ws = wb.active

    # 如果没有提供分段信息，使用默认处理
    for i in range(len(data1[0])):
        ws.cell(1, i + 1, i + 1)
    ws.cell(1, len(data1[0]) + 1, len(data1[0]) + 1)
    for i in range(len(data1)):
        for j in range(len(data1[0])):
            ws.cell(i + 2, j + 1, data1[i][j])
    for jj in range(len(data2)):
        ws.cell(jj + 2, len(data1[0]) + 1, data2[jj])
        if jj ==i:
            break

    path = path.split('.')[0]
    name = path + '-Gaussian-alldata.xlsx'
    wb.save(name)
    path = to_pkl(name)
    return path


def to_data_or(data1, data2, path):
    """
    参数:
    data1: 分段重构后的数据列表，每个元素是一个分段的结果
    data2: 对应的浓度数据
    path: 保存路径
    """
    wb = Workbook()
    wb.create_sheet(index=0, title="all")
    ws = wb.active

    for i in range(len(data1[0])):
        ws.cell(1, i + 1, i + 1)
    ws.cell(1, len(data1[0]) + 1, len(data1[0]) + 1)
    for i in range(len(data1)):
        for j in range(len(data1[0])):
            ws.cell(i + 2, j + 1, data1[i][j])
    for jj in range(len(data2)):
        ws.cell(jj + 2, len(data1[0]) + 1, data2[jj])
        if jj == i:
            break

    path = path.split('.')[0]
    name = path + '-Gaussian-alldata.xlsx'
    wb.save(name)
    path = to_pkl(name)
    return path


def find_closest_number(arr, target):
    diff = []
    arr = list(arr)
    for i, num in enumerate(arr):
        diff.append(abs(num - target))
    min_diff = min(diff)
    index = diff.index(min_diff)
    closest_number = arr[index]
    arr.pop(index)
    return closest_number, index

def gaussian_func(x_data):
    x_max = np.max(abs(x_data))
    x = np.linspace(-5, 5, 1000 * len(x_data[0]))
    y = (x_max/10 - np.exp(-0.5 * x ** 2)) * x_max/(1-x_max/10)
    indexs = []
    xvaluelist = []
    yvaluelist = []
    arr = list(y)
    for i in x_data[0]:
        # closest_number, index = find_closest_number(y, i)
        diff = []
        for iii, num in enumerate(arr):
            diff.append(abs(num - i))
        min_diff = min(diff)
        index = diff.index(min_diff)
        closest_number = arr[index]
        arr[index] = 100000000
        # arr.pop(index)
        indexs.append(index)
        yvaluelist.append(closest_number)
    for ii in range(len(indexs)):
        xvaluelist.append(x[indexs[ii]])
    sorted_values, sorted_indices = index_arrangement(indexs)
    indexs_, xvaluelist, yvaluelist = zip(*sorted(zip(indexs, xvaluelist, yvaluelist)))
    return indexs, xvaluelist, yvaluelist, sorted_indices, indexs_

    print("indexs 是否单调递增：", np.all(np.diff(indexs) > 0))
    print("indexs 是否唯一：", len(indexs) == len(set(indexs)))


def gaussian_funcc(x, a, D):
    return a * (D+(-1)*np.exp(-0.5 * x ** 2 ))


def Gaussian_reconstruction(path):

    df = pd.read_excel(path)
    data_x = df.values[:, 0:-1]
    data_y = df.values[:, -1]

    print("data_x length:", len(data_x[0]))

    # 标准谱
    path_linear = "File address"
    df_linear = pd.read_excel(path_linear)

    data_linear = df_linear.values
    data_x_linear = data_linear[:, 0:-1]

    indexlist, xvaluelist, yvaluelist, sorted_indices, indexlist_ = gaussian_func(data_x_linear)

    all_rows = []

    for i in range(len(data_x)):

        indexs_, yvaluelist_ = zip(*sorted(zip(indexlist, data_x[i])))

        popt, pcov = curve_fit(gaussian_funcc, xvaluelist, yvaluelist_)

        gaussian_y = gaussian_funcc(np.array(xvaluelist), popt[0], popt[1])

        # 写入x
        row1 = list(xvaluelist)
        row1.append(data_y[i])

        # 写入y
        row2 = list(-(gaussian_y))
        row2.append(data_y[i])

        all_rows.append(row1)
        all_rows.append(row2)

        if i % 500 == 0:
            print("processing:", i)

        if i > 8:
            break

    # 恢复列名：前 N 列为 1,2,...,N，最后一列保留原始标签列名
    n_feat = len(all_rows[0]) - 1
    cols = list(range(1, n_feat + 1)) + [df.columns[-1]]
    result = pd.DataFrame(all_rows, columns=cols)
    save_path = path_linear.split('.')[0] + "-Gaussian-data.xlsx"
    result.to_excel(save_path, index=False)

    print("保存完成:", save_path)




if __name__ == '__main__':
     path = "File address"
     Gaussian_reconstruction(path)
